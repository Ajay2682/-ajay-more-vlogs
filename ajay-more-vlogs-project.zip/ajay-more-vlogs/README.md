# Ajay More Vlogs

A responsive, dark-and-gold travel vlog landing page built with plain HTML, CSS and JavaScript. No build tools or package installation are required.

## Run locally

1. Download or clone this repository.
2. Open `index.html` in your browser.

For a local development server, you can use the VS Code **Live Server** extension.

## Before publishing

Update the sample content in `index.html`:

- Replace the YouTube and Instagram links with your real public profile URLs.
- Replace `hello@example.com` with an email address you want visitors to use.
- Replace the sample journey cards and gallery artwork with your own vlog titles and photographs.
- Add your real YouTube video URL when you have a video to feature.

The current contact area uses ordinary links. It does not collect or send form submissions. If you later want a contact form, connect it to a trusted form service or your own backend.

## Deploy

You can publish this static site using GitHub Pages:

1. Push the project files to your GitHub repository.
2. Open **Settings → Pages** in the repository.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select `main` and `/ (root)`, then save.

## Project files

- `index.html` — page content and structure
- `styles.css` — layout, colors and responsive styles
- `script.js` — mobile navigation, scroll progress and gallery lightbox
