const menuToggle = document.querySelector("#menuToggle");
const nav = document.querySelector("#mainNav");
menuToggle.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(open));
});
nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  nav.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
}));

document.querySelector("#year").textContent = new Date().getFullYear();

const progress = document.querySelector("#progress");
window.addEventListener("scroll", () => {
  const max = document.documentElement.scrollHeight - window.innerHeight;
  progress.style.width = `${max > 0 ? (window.scrollY / max) * 100 : 0}%`;
}, { passive: true });

const lightbox = document.querySelector("#lightbox");
const lightboxTitle = document.querySelector("#lightboxTitle");
document.querySelectorAll(".gallery-tile").forEach(tile => {
  tile.addEventListener("click", () => {
    lightboxTitle.textContent = tile.dataset.title;
    lightbox.classList.add("open");
  });
});
function closeLightbox() { lightbox.classList.remove("open"); }
document.querySelector("#closeLightbox").addEventListener("click", closeLightbox);
lightbox.addEventListener("click", event => {
  if (event.target === lightbox) closeLightbox();
});
document.addEventListener("keydown", event => {
  if (event.key === "Escape") closeLightbox();
});
